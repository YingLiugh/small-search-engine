/* 
 * index - a set of functions for creating, saving, loading the index
 * 
 * See index.h for interface descriptions.
 * 
 * Name, Summer 2016
 */

/*  write your implementation of the functions exposed in index.h   */
