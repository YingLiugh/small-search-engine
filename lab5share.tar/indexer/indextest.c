/* 
 * indextest - load an index, and save it, to test those functions
 *
 * 
 * Name, Summer 2016
 */